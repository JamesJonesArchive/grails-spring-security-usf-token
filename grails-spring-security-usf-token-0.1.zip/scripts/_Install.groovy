println '''
**************************************************************
* You've installed the Spring Security USF Token plugin.     *
*                                                            *
* Next run the "usf-token-config" script to add the default  *
* values to your configuration.                              *
*                                                            *
**************************************************************
'''